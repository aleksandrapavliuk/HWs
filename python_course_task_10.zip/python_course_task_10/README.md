## ITMO Python DA course

Код к модулю 10 - Создание API

API на FastAPI для инференса модели предсказания показателя прогрессирования диабета

### Как запустить проект

Для запуска установите зависимости:

```pip install -r python_course_task_10/requirements.txt```

Запустите в корне проекта Streamlit:

```uvicorn main:app```

