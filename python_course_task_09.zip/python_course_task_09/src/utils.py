import os
import pickle

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import RandomizedSearchCV



def prepare_data():

    df = pd.read_csv("python_course_task_09/data/realty_data.csv")

    # дропаем столбцы с (неинформативной) инфой + убираем пропуски
    train = df.drop(columns=["period", "settlement", "area", "description", "address_name",
                            "product_name", "postcode", "lat", "lon",
                            "object_type", "city", "district", "source"]).dropna().reset_index(drop=True)

    return train


def train_model(train):
    lr = LinearRegression()
    X, y = train.drop("price", axis=1), train['price']

    lr.fit(X, y)

    with open('python_course_task_09/lr_fitted.pkl', 'wb') as file:
        pickle.dump(lr, file)


def read_model(model_path):
    if not os.path.exists(model_path):
        raise FileNotFoundError("Model file not exists")

    with open(model_path, 'rb') as file:
        model = pickle.load(file)

    return model

