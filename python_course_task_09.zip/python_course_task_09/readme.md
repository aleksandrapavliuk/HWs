## ITMO Python DA course

Код к модулю 09 - прототипирование ML решений: Google Colab, Streamlit.

Streamlit-демо и Jupyter Notebook интерфейс для модели предсказания выживаемости на Титанике.

### Как запустить проект

Для запуска демо на Streamlit установите зависимости:

```pip install -r requirements.txt```

Запустите в корне проекта Streamlit:

```streamlit run python_course_task_09/main.py```

