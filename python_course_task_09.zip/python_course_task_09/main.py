import os

import pandas as pd
import streamlit as st

from src.utils import prepare_data, train_model, read_model

st.set_page_config(
    page_title="Real estate App",
)


model_path = 'python_course_task_09/lr_fitted.pkl'

total_square = st.sidebar.number_input("Total square in m2", 5, 2000, 50)

rooms = st.sidebar.number_input(
    "How many rooms",
    1, 15, 3,
)
floor = st.sidebar.number_input(
    "Which floor",
    1, 70, 10,
)



# create input DataFrame
inputDF = pd.DataFrame(
    {
        "total_square": total_square,
        "rooms": rooms,
        "floor": floor,
    },
    index=[0],
)

if not os.path.exists(model_path):
    train_data = prepare_data()
    train_data.to_csv('python_course_task_09/data.csv')
    train_model(train_data)

model = read_model('python_course_task_09/lr_fitted.pkl')

preds = model.predict(inputDF)

if st.button('Get result'):
     st.write(f"Your Price based on the information provided is: {preds} RUB")
else:
     st.write("Calculate approximate price of a flat")

